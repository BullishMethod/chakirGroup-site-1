<?php

		// Exit if accessed directly
		if ( ! defined( 'ABSPATH' ) ) {
			exit;
		}

		function fusion_builder_add_agency_demo( $demos ) {

		$demos['agency'] = array (
  'category' => 'Avada Agency',
  'pages' => 
  array (
     
    array (
      'name' => 'Home',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container background_color="yes" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="95px" padding_bottom="20px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_content_boxes settings_lvl="child" layout="icon-on-top" columns="3" icon_align="left" animation_type="0" animation_direction="left" animation_speed="0.1"][fusion_content_box title="Responsive Design" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/146x140" image_width="73" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][fusion_content_box title="Premium Sliders" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/152x140" image_width="76" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][fusion_content_box title="HTML 5 Video" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/112x140" image_width="56" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][/fusion_content_boxes][fusion_separator style_type="none" top_margin="-15" bottom_margin="-15" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_content_boxes settings_lvl="child" layout="icon-on-top" columns="3" icon_align="left" animation_type="0" animation_direction="left" animation_speed="0.1"][fusion_content_box title="Built In tools" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/136x140" image_width="68" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][fusion_content_box title="Beautiful Imagery" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/146x140" image_width="73" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][fusion_content_box title="Amazing Interface" icon="" backgroundcolor="" iconcolor="#6796bf" circlecolor="#ffffff" circlebordercolor="#6796bf" circlebordersize="" outercirclebordercolor="" outercirclebordersize="" iconrotate="" iconspin="no" image="https://placehold.it/136x140" image_width="68" image_height="70" link="#" linktext="" link_target="_self" animation_type="0" animation_direction="down" animation_speed="0.1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit sed eiusmod tempor incididui labore dolore magna sadipieds etas lorems.[/fusion_content_box][/fusion_content_boxes][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="#6796bf" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left center" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="27px" padding_bottom="10px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h2 style="text-align: center;"><span style="color: #ffffff;">Recent Projects We\'ve Completed For Our Clients</span></h2>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="0px" padding_bottom="0px" padding_left="0px" padding_right="0px" hundred_percent="yes" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_portfolio layout="grid" picture_size="auto" boxed_text="unboxed" filters="no" columns="3" column_spacing="0" number_posts="6" excerpt_length="35" strip_html="yes" carousel_layout="title_on_rollover" autoplay="no" show_nav="yes" mouse_scroll="no" animation_type="0" animation_direction="down" animation_speed="0.1" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" equal_height_columns="no" hide_on_mobile="small-visibility,medium-visibility,large-visibility" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" video_loop="yes" video_mute="yes" border_style="solid" margin_top="-43px" margin_bottom="-40px"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_separator style_type="none" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="#6796bf" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="25px" padding_bottom="20px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="single solid" top_margin="43" bottom_margin="0" sep_color="rgba(255,255,255,.4)" /][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="none" top_margin="14" bottom_margin="0" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="xlarge" stretch="default" type="flat" shape="round" target="_blank" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255, 255, 255, 0.09)" button_gradient_bottom_color_hover="rgba(255, 255, 255, 0.09)" accent_color="rgba(255,255,255,.6)" accent_hover_color="rgba(255,255,255,.9)" border_width="1px" icon_position="left" icon_divider="no" animation_type="0" animation_direction="left" animation_speed="1" alignment="center"]Buy Avada Now![/fusion_button][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="single solid" top_margin="43" bottom_margin="0" sep_color="rgba(255,255,255,.4)" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_image="https://placehold.it/500x301" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="60px" padding_bottom="0px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;">We Build Solutions For Your Everyday Problems</h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="10" bottom_margin="65" sep_color="rgba(000,000,000,.3)" width="350px" alignment="center" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="down" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/1088x467" alt="" />[/fusion_imageframe][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="#fff" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left center" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="27px" padding_bottom="10px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h2 style="text-align: center;">Some Words From Our Clients</h2>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container admin_label="" hundred_percent="no" equal_height_columns="no" menu_anchor="" hide_on_mobile="no" class="" id="" background_color="rgba(103,150,191,0.9)" background_image="" background_position="left top" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" video_mp4="https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2017/03/video_agency_page_xml.mp4" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="https://placehold.it/1100x600" border_size="0px" border_color="" border_style="solid" margin_top="" margin_bottom="" padding_top="85px" padding_right="" padding_bottom="75px" padding_left=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_testimonials design="clean" backgroundcolor="transparent" textcolor="#ffffff"][fusion_testimonial name="Tommy Tall Boy" avatar="image" image="https://placehold.it/152x151" image_border_radius="100px" company="" link="" target="_self"]Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem sadips ipsums aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. [/fusion_testimonial][fusion_testimonial name="Plain Jane" avatar="image" image="https://placehold.it/152x151" image_border_radius="100px" company="" link="" target="_self"]Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem sadips ipsums aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. [/fusion_testimonial][/fusion_testimonials][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="60px" padding_bottom="55px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;">Our Proven Process Produces Results</h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="10" bottom_margin="65" sep_color="rgba(000,000,000,.3)" width="350px" alignment="center" /][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_counters_circle][fusion_counter_circle filledcolor="#6798bd" unfilledcolor="rgba(000,000,000,.05)" size="200" scales="no" countdown="no" speed="1500" value="20"][fusion_fontawesome icon="fa-comments-o" circle="no" size="large" iconcolor="#6798bd" circlecolor="" circlebordercolor="" flip="" rotate="" spin="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center" class="" id=""/][/fusion_counter_circle][/fusion_counters_circle][fusion_text]
<h3 style="text-align: center;">1. MEETING</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="25" sep_color="rgba(000,000,000,.3)" width="120px" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit etra amets, consectetur adipiscing elit, sedips do eiusmod tempor incid et dolor. Ut enim ad minim.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_counters_circle][fusion_counter_circle filledcolor="#cea96c" unfilledcolor="rgba(000,000,000,.05)" size="200" scales="no" countdown="no" speed="2500" value="40"][fusion_fontawesome icon="fa-briefcase" circle="no" size="large" iconcolor="#cea96c" circlecolor="" circlebordercolor="" flip="" rotate="" spin="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center" class="" id=""/][/fusion_counter_circle][/fusion_counters_circle][fusion_text]
<h3 style="text-align: center;">2. PLANNING</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="25" sep_color="rgba(000,000,000,.3)" width="120px" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit etra amets, consectetur adipiscing elit, sedips do eiusmod tempor incid et dolor. Ut enim ad minim.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_counters_circle][fusion_counter_circle filledcolor="#b7c289" unfilledcolor="rgba(000,000,000,.05)" size="200" scales="no" countdown="no" speed="3500" value="60"][fusion_fontawesome icon="fa-code" circle="no" size="large" iconcolor="#b7c289" circlecolor="" circlebordercolor="" flip="" rotate="" spin="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center" class="" id=""/][/fusion_counter_circle][/fusion_counters_circle][fusion_text]
<h3 style="text-align: center;">3. EXECUTE</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="25" sep_color="rgba(000,000,000,.3)" width="120px" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit etra amets, consectetur adipiscing elit, sedips do eiusmod tempor incid et dolor. Ut enim ad minim.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_counters_circle][fusion_counter_circle filledcolor="#c06d3f" unfilledcolor="rgba(000,000,000,.05)" size="200" scales="no" countdown="no" speed="2500" value="80"][fusion_fontawesome icon="fa-support" circle="no" size="large" iconcolor="#cea96c" circlecolor="" circlebordercolor="" flip="" rotate="" spin="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center" class="" id=""/][/fusion_counter_circle][/fusion_counters_circle][fusion_text]
<h3 style="text-align: center;">4. TESTING</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="25" sep_color="rgba(000,000,000,.3)" width="120px" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit etra amets, consectetur adipiscing elit, sedips do eiusmod tempor incid et dolor. Ut enim ad minim.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_counters_circle][fusion_counter_circle filledcolor="#000000" unfilledcolor="rgba(000,000,000,.05)" size="200" scales="no" countdown="no" speed="4500" value="100"][fusion_fontawesome icon="fa-paper-plane-o" circle="no" size="large" iconcolor="#000" circlecolor="" circlebordercolor="" flip="" rotate="" spin="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center" class="" id=""/][/fusion_counter_circle][/fusion_counters_circle][fusion_text]
<h3 style="text-align: center;">5. DELIVERY</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="25" sep_color="rgba(000,000,000,.3)" width="120px" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit etra amets, consectetur adipiscing elit, sedips do eiusmod tempor incid et dolor. Ut enim ad minim.</p>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="yes" background_image="https://placehold.it/1600x1002" background_parallax="up" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="100px" padding_bottom="100px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="no" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/155x120" alt="" />[/fusion_imageframe][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">We\'re Here To Help Your Business Blast Off!</span></h1>
<p style="font-size: 18px; margin-top: -20px; text-align: center;"><span style="color: #ffffff;">Through Creative Ideas, Innovation &amp; Sheer Determination</span></p>
[/fusion_text][fusion_separator style_type="none" top_margin="9" bottom_margin="9" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="xlarge" stretch="default" type="flat" shape="round" target="_blank" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255, 255, 255, 0.09)" button_gradient_bottom_color_hover="rgba(255, 255, 255, 0.09)" accent_color="rgba(255,255,255,.6)" accent_hover_color="rgba(255,255,255,1)" border_width="1px" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="center"]Let\'s Get Started![/fusion_button][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" overflow="visible"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_modal name="contact" title="We\'d Love To Hear From You!" size="large" background="#ffffff" show_footer="yes"][fusion_builder_row_inner][fusion_builder_column_inner type="2_5" last="no" class="" id=""]
[fusion_separator style_type="none" top_margin="10" bottom_margin="0" sep_color="" icon="" width="" class="" id=""/]

[fusion_imageframe lightbox="no" style_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="none" link="" linktarget="_self" animation_type="0" animation_direction="down" animation_speed="0.1" class="" id=""]<img src="https://placehold.it/250x93" alt="" />[/fusion_imageframe]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Fill out the form and our team will be in touch with you promptly. Thank you for your interest!

<strong>12345 North West Street
New York City, NY 555555
555.555.5555</strong>

info@yourdomain.com
www.yourdomain.com[/fusion_text]
[/fusion_builder_column_inner]

[fusion_builder_column_inner type="3_5" last="yes" class="" id=""]
[fusion_text][contact-form-7 id="11449" title="Contact form 1"][/fusion_text]
[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_modal][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => 'agency-home-video',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'flex',
        'pyre_slider' => '0',
        'pyre_wooslider' => 'agency-home-video',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '0px',
        'pyre_main_bottom_padding' => '0px',
        'pyre_hundredp_padding' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'default',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'default',
        'pyre_page_title_custom_text' => '',
        'pyre_page_title_text_size' => '',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => '',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'default',
        'pyre_page_title_bg_parallax' => 'default',
      ),
    ),
     
    array (
      'name' => 'Blog',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container hundred_percent="yes" equal_height_columns="no" menu_anchor="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" class="" id="" background_color="" background_image="" background_position="center center" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="" video_loop="yes" video_mute="yes" overlay_color="" overlay_opacity="" video_preview_image="" border_size="" border_color="" border_style="solid" margin_top="" margin_bottom="" padding_top="" padding_right="40px" padding_bottom="" padding_left="40px"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_blog number_posts="6" offset="" cat_slug="" exclude_cats="" show_title="yes" title_link="yes" thumbnail="yes" excerpt="yes" excerpt_length="27" meta_all="yes" meta_author="yes" meta_categories="yes" meta_comments="yes" meta_date="yes" meta_link="yes" meta_tags="yes" paging="no" scrolling="infinite" strip_html="yes" blog_grid_columns="4" blog_grid_column_spacing="40" layout="grid" class="" id="" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => '',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'no',
        'pyre_slider' => '0',
        'pyre_wooslider' => '0',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '40px',
        'pyre_main_bottom_padding' => '',
        'pyre_hundredp_padding' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'none',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'center',
        'pyre_page_title_custom_text' => 'Latest From The Blog',
        'pyre_page_title_text_size' => '60px',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '#fff',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '300px',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => '',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'yes',
        'pyre_page_title_bg_parallax' => 'default',
      ),
    ),
     
    array (
      'name' => 'About Us',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="0px" padding_bottom="50px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h3 style="text-align: center;">OUR MISSION IS TO HARNESS OUR CREATIVITY INTO A VIABLE SOLUTION</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="45" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="no" gallery_id="" lightbox_image="" style_type="none" hover_type="none" bordercolor="" bordersize="0px" borderradius="" stylecolor="" align="center" link="" linktarget="_self" animation_type="fade" animation_direction="left" animation_speed="1" animation_offset="" hide_on_mobile="no" class="" id=""] <img src="https://placehold.it/850x279" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="20" bottom_margin="10" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="" alignment="center" class="" id="" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]adipiscing elit[/fusion_popover]. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat. Sed egestas consequat augue eu iaculis. Donec elementum pellentesque. Sed gravida, nisl ac lobortis pulvinar, augue est vulputate felis, vel pulvinar ex eros sed est. In hac habitasse platea dicssa. Duis sodales eleifend sem, nonsi semper dui [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""] consectetur non[/fusion_popover]. Proin leo nunc, tempus eget urna id, maximus commodo odio. Lorem ipsum dolor sit amet, consectetur adipiscing elits sadips. Praesent a felis lacus. Nunc at vulputate justo.</p>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="27px" padding_bottom="10px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h2 style="text-align: center;"><span style="color: #ffffff;">We Thrive On Challenging Projects That Produce Bigger Rewards.</span></h2>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="https://placehold.it/500x301" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="80px" padding_bottom="30px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_text]
<h3 style="text-align: center;">The Right Tools. The Right Solution.</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="rgba(000,000,000,.3)" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent per conubia nostras..</p>
[/fusion_text][fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="" alignment="" class="" id="" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,.1)" button_gradient_bottom_color="rgba(255,255,255,.1)" button_gradient_top_color_hover="rgba(255,255,255,.4)" button_gradient_bottom_color_hover="rgba(255,255,255,.4)" accent_color="#6796bf" accent_hover_color="#608eb6" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="down" animation_speed="0.1" animation_offset="" alignment="center" class="" id=""]PURCHASE AVADA[/fusion_button][/fusion_builder_column][fusion_builder_column type="2_3" layout="2_3" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_flip_boxes columns="3" hide_on_mobile="small-visibility,medium-visibility,large-visibility" class="" id=""][fusion_flip_box title_front="Beautiful Images" title_back="Images Tell A Story" text_front="Images tell a story, share a feeling and reveal information to your viewer." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#6796bf" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_flip="" icon_rotate="" icon_spin="yes" image="https://placehold.it/152x140" image_width="76" image_height="70" animation_type="" animation_direction="down" animation_speed="1" animation_offset=""]

Rest assure we will incorporate beautiful imagery into your project so it stands out to the world.

[/fusion_flip_box][fusion_flip_box title_front="Intuitive Options" title_back="Interfaces Matter" text_front="Our intuitive options allow you to quickly and easily customize your web site." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#e0be8a" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_rotate="" icon_spin="yes" image="https://placehold.it/136x140" image_width="68" image_height="70" animation_type="0" animation_direction="down" animation_speed="1" animation_offset=""]Options are useless without a clear understanding of what they do. We include intuitive, easy to use options.[/fusion_flip_box][fusion_flip_box title_front="Responsive" title_back="Looks Amazing" text_front="No matter what screen size or device, your content will look amazing." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#b6c387" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_flip="" icon_rotate="" icon_spin="yes" image="https://placehold.it/146x140" image_width="73" image_height="70" animation_type="" animation_direction="down" animation_speed="1" animation_offset=""]

Your content matters most, and needs to be accessible anywhere, anytime. This happens with our framework.

[/fusion_flip_box][/fusion_flip_boxes][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container admin_label="" hundred_percent="no" equal_height_columns="no" menu_anchor="" hide_on_mobile="no" class="" id="" background_color="rgba(0,0,0,0.65)" background_image="" background_position="left top" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" video_mp4="https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2017/03/video_agency_page_xml.mp4" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" video_preview_image="https://placehold.it/1100x600" border_size="0px" border_color="" border_style="solid" margin_top="" margin_bottom="" padding_top="50px" padding_right="" padding_bottom="55px" padding_left=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_counters_box columns="3" color="" title_size="" icon_size="" icon_top="" body_color="" body_size="" border_color="" animation_offset="" hide_on_mobile="small-visibility,medium-visibility,large-visibility" class="" id=""][fusion_counter_box value="300000" delimiter="," unit="" unit_pos="suffix" icon="fa-heart-o" direction="up"]Satisfied Users[/fusion_counter_box][fusion_counter_box value="11500" delimiter="," unit="" unit_pos="suffix" icon="fa-coffee" direction="up"]Cups of Coffee[/fusion_counter_box][fusion_counter_box value="13000" delimiter="," unit="" unit_pos="suffix" icon="fa-code" direction="up"]Development Hours[/fusion_counter_box][/fusion_counters_box][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="55px" padding_bottom="70px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;">Meet Your New Best Friends, Our Gurus.</h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="55" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_person name="John Doe" title="Developer" picture="https://placehold.it/580x388" pic_link="" linktarget="_self" pic_style="none" hover_type="none" background_color="" content_alignment="" pic_style_color="" pic_bordersize="0" pic_bordercolor="" pic_borderradius="" icon_position="" social_icon_boxed="yes" social_icon_boxed_radius="4px" social_icon_color_type="" social_icon_colors="" social_icon_boxed_colors="" social_icon_tooltip="top" email="" facebook="http://facebook.com" twitter="http://twitter.com" instagram="" dribbble="http://dribbble.com" google="" linkedin="" blogger="" tumblr="" reddit="" yahoo="" deviantart="" vimeo="" youtube="" pinterest="" rss="" digg="" flickr="" forrst="" myspace="" skype="" paypal="" dropbox="" soundcloud="" vk="" xing="" show_custom="no" class="" id=""]Redantium, totam rem aperiam, eaque ipsa qu ab illo inventore veritatis et quasi architectos beatae vitae dicta sunt explicaboemo enimse ets.[/fusion_person][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_progress height="" text_position="" percentage="93" show_percentage="" unit="%" filledcolor="" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]Graphic Design[/fusion_progress][fusion_progress height="" text_position="" percentage="86" show_percentage="" unit="%" filledcolor="" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]Graphic Design[/fusion_progress][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_person name="Jane Doe" title="Developer" picture="https://placehold.it/580x388" pic_link="" linktarget="_self" pic_style="none" hover_type="none" background_color="" content_alignment="" pic_style_color="" pic_bordersize="0" pic_bordercolor="" pic_borderradius="" icon_position="" social_icon_boxed="yes" social_icon_boxed_radius="4px" social_icon_color_type="" social_icon_colors="" social_icon_boxed_colors="" social_icon_tooltip="top" email="" facebook="http://facebook.com" twitter="http://twitter.com" instagram="" dribbble="http://dribbble.com" google="" linkedin="" blogger="" tumblr="" reddit="" yahoo="" deviantart="" vimeo="" youtube="" pinterest="" rss="" digg="" flickr="" forrst="" myspace="" skype="" paypal="" dropbox="" soundcloud="" vk="" xing="" show_custom="no" class="" id=""]Redantium, totam rem aperiam, eaque ipsa qu ab illo inventore veritatis et quasi architectos beatae vitae dicta sunt explicaboemo enimse ets.[/fusion_person][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_progress height="" text_position="" percentage="96" show_percentage="" unit="%" filledcolor="#b6c387" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]WordPress[/fusion_progress][fusion_progress height="" text_position="" percentage="85" show_percentage="" unit="%" filledcolor="#b6c387" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]Web Design[/fusion_progress][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_person name="Jim Doe" title="Developer" picture="https://placehold.it/580x388" pic_link="" linktarget="_self" pic_style="none" hover_type="none" background_color="" content_alignment="" pic_style_color="" pic_bordersize="0" pic_bordercolor="" pic_borderradius="" icon_position="" social_icon_boxed="yes" social_icon_boxed_radius="4px" social_icon_color_type="" social_icon_colors="" social_icon_boxed_colors="" social_icon_tooltip="top" email="" facebook="http://facebook.com" twitter="http://twitter.com" instagram="" dribbble="http://dribbble.com" google="" linkedin="" blogger="" tumblr="" reddit="" yahoo="" deviantart="" vimeo="" youtube="" pinterest="" rss="" digg="" flickr="" forrst="" myspace="" skype="" paypal="" dropbox="" soundcloud="" vk="" xing="" show_custom="no" class="" id=""]Redantium, totam rem aperiam, eaque ipsa qu ab illo inventore veritatis et quasi architectos beatae vitae dicta sunt explicaboemo enimse ets.[/fusion_person][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_progress height="" text_position="" percentage="89" show_percentage="" unit="%" filledcolor="#ceaa69" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]HTML/CSS[/fusion_progress][fusion_progress height="" text_position="" percentage="95" show_percentage="" unit="%" filledcolor="#ceaa69" filledbordercolor="" filledbordersize="" unfilledcolor="" striped="yes" animated_stripes="yes" textcolor="" class="" id=""]Javascript[/fusion_progress][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="https://placehold.it/1600x1002" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="center center" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="55px" padding_bottom="100px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">We Are Global And Have Helped Clients Worldwide.</span></h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="45" sep_color="rgba(255,255,255,.4)" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_map address="Brazil|Saudi Arabia|South Africa|New York City, NY|New Zealand" type="roadmap" map_style="custom" overlay_color="#6796bf" infobox="custom" infobox_background_color="rgba(000,000,000,.4)" infobox_text_color="#ffffff" infobox_content="" icon="https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png" width="100%" height="550px" zoom="2" scrollwheel="no" scale="yes" zoom_pancontrol="yes" animation="yes" popup="no" class="" id="" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="repeat" background_position="center center" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="75px" padding_bottom="70px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_3" layout="1_3" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_text]
<h1 style="text-align: center;">We Thrive Ourselves On Creativity, Intuition &amp; Determination.</h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent per conubia nostras..</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="none" top_margin="17" bottom_margin="13" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<h3 style="text-align: center;">We Are Creative</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitis sociosqu ad litora.</p>
[/fusion_text][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="#6797be" button_gradient_bottom_color_hover="#6797be" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" animation_offset="" alignment="center" class="" id=""]Learn More[/fusion_button][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="none" top_margin="17" bottom_margin="13" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<h3 style="text-align: center;">We Have Intuition</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitis sociosqu ad litora.</p>
[/fusion_text][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="#6797be" button_gradient_bottom_color_hover="#6797be" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" animation_offset="" alignment="center" class="" id=""]Learn More[/fusion_button][/fusion_builder_column][fusion_builder_column type="1_5" layout="1_5" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_separator style_type="none" top_margin="17" bottom_margin="13" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<h3 style="text-align: center;">We Are Determined</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="100px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitis sociosqu ad litora.</p>
[/fusion_text][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="#6797be" button_gradient_bottom_color_hover="#6797be" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" animation_offset="" alignment="center" class="" id=""]Learn More[/fusion_button][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="rgba(255,255,255,0.5)" background_image="https://placehold.it/1600x1002" background_parallax="up" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="100px" padding_bottom="100px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="center" gallery_id="" lightbox_image="" style_type="none" hover_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="center" link="" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" animation_offset="" hide_on_mobile="no" class="" id=""] <img src="https://placehold.it/155x120" alt="" />[/fusion_imageframe][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">We\'re Here To Help Your Business Blast Off!</span></h1>
<p style="font-size: 18px; margin-top: -20px; text-align: center;"><span style="color: #ffffff;">Through Creative Ideas, Innovation &amp; Sheer Determination</span></p>
[/fusion_text][fusion_separator style_type="none" top_margin="9" bottom_margin="9" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="" alignment="" class="" id="" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="xlarge" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255, 255, 255, 0.09)" button_gradient_bottom_color_hover="rgba(255, 255, 255, 0.09)" accent_color="rgba(255,255,255,.6)" accent_hover_color="rgba(255,255,255,1)" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" animation_offset="" alignment="center" class="" id=""]Let\'s Get Started![/fusion_button][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" overflow="visible"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_modal name="contact" title="We\'d Love To Hear From You!" size="large" background="#ffffff" border_color="" show_footer="yes" class="" id=""][fusion_builder_row_inner][fusion_builder_column_inner type="2_5" last="no" class="" id=""] [fusion_separator style_type="none" top_margin="10" bottom_margin="0" sep_color="" icon="" width="" class="" id=""/] [fusion_imageframe lightbox="no" style_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="none" link="" linktarget="_self" animation_type="0" animation_direction="down" animation_speed="0.1" class="" id=""]<img src="https://placehold.it/250x93" alt="" />[/fusion_imageframe] [fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text] Fill out the form and our team will be in touch with you promptly. Thank you for your interest! <strong>12345 North West Street New York City, NY 555555 555.555.5555</strong> info@yourdomain.com www.yourdomain.com[/fusion_text] [/fusion_builder_column_inner] [fusion_builder_column_inner type="3_5" last="yes" class="" id=""] [fusion_text][contact-form-7 id="11449" title="Contact form 1"][/fusion_text] [/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_modal][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => 'agency-about-us',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'flex',
        'pyre_slider' => '0',
        'pyre_wooslider' => 'agency-about-us',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '',
        'pyre_main_bottom_padding' => '0px',
        'pyre_hundredp_padding' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'none',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'center',
        'pyre_page_title_custom_text' => 'Avada Agency Inc',
        'pyre_page_title_text_size' => '60px',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '#fff',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '350px',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => 'https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/bluebkgd2.jpg',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'yes',
        'pyre_page_title_bg_parallax' => 'yes',
      ),
    ),
     
    array (
      'name' => 'Our Work',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container hundred_percent="yes" equal_height_columns="no" menu_anchor="" hide_on_mobile="no" class="" id="" background_color="" background_image="" background_position="left top" background_repeat="no-repeat" fade="no" background_parallax="none" enable_mobile="no" parallax_speed="0.3" video_mp4="" video_webm="" video_ogv="" video_url="" video_aspect_ratio="16:9" video_loop="yes" video_mute="yes" overlay_color="" overlay_opacity="0.5" video_preview_image="" border_size="0px" border_color="" border_style="solid" margin_top="" margin_bottom="-82px" padding_top="0px" padding_right="0px" padding_bottom="0px" padding_left="0px"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_portfolio layout="grid" picture_size="auto" boxed_text="unboxed" filters="no" columns="3" column_spacing="0" cat_slug="" exclude_cats="" number_posts="12" offset="" excerpt_length="35" strip_html="yes" carousel_layout="title_on_rollover" scroll_items="" autoplay="no" show_nav="yes" mouse_scroll="no" animation_type="0" animation_direction="down" animation_speed="0.1" animation_offset="" class="" id="" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => '',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'no',
        'pyre_slider' => '0',
        'pyre_wooslider' => '0',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '0px',
        'pyre_main_bottom_padding' => '0px',
        'pyre_hundredp_padding' => '',
        'pyre_container_padding_top' => '',
        'pyre_container_padding_right' => '',
        'pyre_container_padding_bottom' => '',
        'pyre_container_padding_left' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'default',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'default',
        'pyre_page_title_custom_text' => '',
        'pyre_page_title_text_size' => '',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => '',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'default',
        'pyre_page_title_bg_parallax' => 'default',
      ),
    ),
     
    array (
      'name' => 'Contact Us',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container background_color="" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" overlay_color="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="0px" padding_bottom="0px" padding_left="0px" padding_right="0px" hundred_percent="yes" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_map address="Bensonhurst, New York|Elm Park, New York|Hamilton Beach, New York|Bayswater, New York" type="roadmap" map_style="custom" overlay_color="#6796bf" infobox="custom" infobox_background_color="rgba(000,000,000,.4)" infobox_text_color="#ffffff" infobox_content="" icon="https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png|https://avada.theme-fusion.com/agency/wp-content/uploads/sites/11/2014/10/agency_logo_icon.png" width="100%" height="520px" zoom="12" scrollwheel="no" scale="no" zoom_pancontrol="yes" animation="yes" popup="no" class="" id="" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" overlay_color="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="75px" padding_bottom="20px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_flip_boxes columns="3" class="" id=""][fusion_flip_box title_front="Service Questions" title_back="Lorem Ipsum Sadips" text_front="Nemo enim ipsam voluptatem quia voluptas sit aspernatur sadips etra dolores." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#6796bf" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_rotate="" icon_spin="yes" image="" image_width="" image_height="" animation_type="0" animation_direction="down" animation_speed="1" animation_offset=""]Sed ut perspiciatis unde omnis iste natus error sits voluptatem accusantium doloremque laudantium.[/fusion_flip_box][fusion_flip_box title_front="Product Support" title_back="Lorem Ipsum Sadips" text_front="Nemo enim ipsam voluptatem quia voluptas sit aspernatur sadips etra dolores." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#e0be8a" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_rotate="" icon_spin="yes" image="" image_width="" image_height="" animation_type="0" animation_direction="down" animation_speed="1" animation_offset=""]Sed ut perspiciatis unde omnis iste natus error sits voluptatem accusantium doloremque laudantium.[/fusion_flip_box][fusion_flip_box title_front="Partnership Info" title_back="Lorem Ipsum Sadips" text_front="Nemo enim ipsam voluptatem quia voluptas sit aspernatur sadips etra dolores." background_color_front="rgba(000,000,000,.05)" title_front_color="#333333" text_front_color="#747474" background_color_back="#b6c387" title_back_color="#eeeded" text_back_color="#ffffff" border_size="0px" border_color="" border_radius="4px" icon="" icon_color="" circle="yes" circle_color="" circle_border_color="" icon_rotate="" icon_spin="yes" image="" image_width="" image_height="" animation_type="0" animation_direction="down" animation_speed="1" animation_offset=""]Sed ut perspiciatis unde omnis iste natus error sits voluptatem accusantium doloremque laudantium.[/fusion_flip_box][/fusion_flip_boxes][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="" background_image="" background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" overlay_color="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="20px" padding_bottom="25px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_2" layout="1_2" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_imageframe lightbox="center" lightbox_image="" style_type="none" hover_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="center" link="" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" animation_offset="" hide_on_mobile="no" class="" id=""] <img src="https://placehold.it/250x93" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="25" bottom_margin="25" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_text]
<h3 style="text-align: center;">We\'d love To Meet You In Person Or Via The Web!</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#e0e0e0" border_size="" icon="" icon_circle="" icon_circle_color="" width="200px" alignment="" class="" id="" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]adipiscing elit[/fusion_popover]. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat.</p>
<p style="text-align: center;"><strong>Main Office:</strong> 123 Elm St. New York City, NY 111111
<strong>Phone:</strong> 1.555.555.5555
<strong>Email:</strong> <a href="#" target="_top">info@yourdomain.com</a></p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_2" layout="1_2" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_code]W2NvbnRhY3QtZm9ybS03IGlkPSIxMjAwMiIgdGl0bGU9IkNvbnRhY3QgUGFnZSBGb3JtIl0=[/fusion_code][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="none" lightbox_image="" style_type="none" hover_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="none" link="" linktarget="_self" animation_type="0" animation_direction="" animation_speed="0.1" animation_offset="" hide_on_mobile="no" class="" id=""] <img alt="" />[/fusion_imageframe][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_color="yes" background_image="https://placehold.it/1600x1002" background_parallax="up" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_url="" video_aspect_ratio="16:9" video_webm="" video_mp4="" video_ogv="" video_preview_image="" overlay_color="" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_color="" border_style="solid" padding_top="100px" padding_bottom="100px" padding_left="" padding_right="" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no" menu_anchor="" class="" id=""][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="center" lightbox_image="" style_type="none" hover_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="center" link="" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" animation_offset="" hide_on_mobile="no" class="" id=""] <img src="https://placehold.it/155x120" alt="" />[/fusion_imageframe][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">We\'re Here To Help Your Business Blast Off!</span></h1>
<p style="font-size: 18px; margin-top: -20px; text-align: center;"><span style="color: #ffffff;">Through Creative Ideas, Innovation &amp; Sheer Determination</span></p>
[/fusion_text][fusion_separator style_type="none" top_margin="9" bottom_margin="9" sep_color="" border_size="" icon="" icon_circle="" icon_circle_color="" width="" alignment="" class="" id="" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="xlarge" stretch="default" type="flat" shape="round" target="_blank" title="" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255, 255, 255, 0.09)" button_gradient_bottom_color_hover="rgba(255, 255, 255, 0.09)" accent_color="rgba(255,255,255,.6)" accent_hover_color="rgba(255,255,255,1)" bevel_color="" border_width="1px" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" animation_offset="" alignment="center" class="" id=""]Let\'s Get Started![/fusion_button][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" overflow="visible"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_modal name="contact" title="We\'d Love To Hear From You!" size="large" background="#ffffff" border_color="" show_footer="yes" class="" id=""][fusion_builder_row_inner][fusion_builder_column_inner type="2_5" last="no" class="" id=""]
[fusion_separator style_type="none" top_margin="10" bottom_margin="0" sep_color="" icon="" width="" class="" id=""/]

[fusion_imageframe lightbox="no" style_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="none" link="" linktarget="_self" animation_type="0" animation_direction="down" animation_speed="0.1" class="" id=""]<img src="https://placehold.it/250x93" alt="" />[/fusion_imageframe]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Fill out the form and our team will be in touch with you promptly. Thank you for your interest!

<strong>12345 North West Street
New York City, NY 555555
555.555.5555</strong>

info@yourdomain.com
www.yourdomain.com[/fusion_text]
[/fusion_builder_column_inner]

[fusion_builder_column_inner type="3_5" last="yes" class="" id=""]
[fusion_text][contact-form-7 id="11449" title="Contact form 1"][/fusion_text]
[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_modal][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => 'agency-contact',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'flex',
        'pyre_slider' => '0',
        'pyre_wooslider' => 'agency-contact',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '0px',
        'pyre_main_bottom_padding' => '0px',
        'pyre_hundredp_padding' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'default',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'default',
        'pyre_page_title_custom_text' => '',
        'pyre_page_title_text_size' => '',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => '',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'default',
        'pyre_page_title_bg_parallax' => 'default',
      ),
    ),
     
    array (
      'name' => 'Services',
      'page_template' => '100-width.php',
      'content' => '[fusion_builder_container background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="0px" padding_bottom="0px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h3 style="text-align: center;">WE OFFER A VARIETY OF CREATIVE SERVICES TO SUITE EVERY NEED</h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="60" sep_color="#e0e0e0" width="200px" alignment="center" /][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_tabs design="clean" layout="horizontal" justified="yes" hide_on_mobile="small-visibility,medium-visibility,large-visibility"][fusion_tab title="Design" icon="fa-laptop"][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" last="no" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="solid" padding="" class="" id=""][fusion_imageframe lightbox="right" style_type="none" bordercolor="" bordersize="0px" borderradius="" stylecolor="" align="none" link="" linktarget="_self" animation_type="fade" animation_direction="left" animation_speed="1" class="" id=""] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][/fusion_builder_column_inner]

[fusion_builder_column_inner type="1_2" last="yes" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="" padding="" class="" id=""]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat. Sed egestas consequat augue eu iaculis. [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]Donec elementum pellentesque.[/fusion_popover] Sed gravida, nisl ac lobortis pulvinar, augue est vulputate felis, vel pulvinar ex eros sed est. In hac habitasse platea dicssa. Duis sodales eleifend sem, nonsi semper dui consectetur on roin leoi.

<em>Tempus eget urna id, maximus commodo odio. Lorem ipsum dolor sit amet, consectetur elits sadips. Praesent alis lacus. Nunc at vulputate justo.</em>

[/fusion_text][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" icon="" width="" class="" id=""/]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Learn More[/fusion_button]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Get A Quote[/fusion_button]

[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_tab][fusion_tab title="Animation" icon="fa-rocket"][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" last="no" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="solid" padding="" class="" id=""][fusion_imageframe lightbox="right" style_type="none" bordercolor="" bordersize="0px" borderradius="" stylecolor="" align="none" link="" linktarget="_self" animation_type="fade" animation_direction="left" animation_speed="1" class="" id=""] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][/fusion_builder_column_inner]

[fusion_builder_column_inner type="1_2" last="yes" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="" padding="" class="" id=""]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat. Sed egestas consequat augue eu iaculis. [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]Donec elementum pellentesque.[/fusion_popover] Sed gravida, nisl ac lobortis pulvinar, augue est vulputate felis, vel pulvinar ex eros sed est. In hac habitasse platea dicssa. Duis sodales eleifend sem, nonsi semper dui consectetur on roin leoi.

<em>Tempus eget urna id, maximus commodo odio. Lorem ipsum dolor sit amet, consectetur elits sadips. Praesent alis lacus. Nunc at vulputate justo.</em>

[/fusion_text][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" icon="" width="" class="" id=""/]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Learn More[/fusion_button]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Get A Quote[/fusion_button]

[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_tab][fusion_tab title="Development" icon="fa-code"][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" last="no" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="solid" padding="" class="" id=""][fusion_imageframe lightbox="right" style_type="none" bordercolor="" bordersize="0px" borderradius="" stylecolor="" align="none" link="" linktarget="_self" animation_type="fade" animation_direction="left" animation_speed="1" class="" id=""] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][/fusion_builder_column_inner]

[fusion_builder_column_inner type="1_2" last="yes" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="" padding="" class="" id=""]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat. Sed egestas consequat augue eu iaculis. [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]Donec elementum pellentesque.[/fusion_popover] Sed gravida, nisl ac lobortis pulvinar, augue est vulputate felis, vel pulvinar ex eros sed est. In hac habitasse platea dicssa. Duis sodales eleifend sem, nonsi semper dui consectetur on roin leoi.

<em>Tempus eget urna id, maximus commodo odio. Lorem ipsum dolor sit amet, consectetur elits sadips. Praesent alis lacus. Nunc at vulputate justo.</em>

[/fusion_text][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" icon="" width="" class="" id=""/]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Learn More[/fusion_button]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Get A Quote[/fusion_button]

[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_tab][fusion_tab title="Video" icon="fa-film"][fusion_builder_row_inner][fusion_builder_column_inner type="1_2" last="no" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="solid" padding="" class="" id=""][fusion_imageframe lightbox="right" style_type="none" bordercolor="" bordersize="0px" borderradius="" stylecolor="" align="none" link="" linktarget="_self" animation_type="fade" animation_direction="left" animation_speed="1" class="" id=""] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][/fusion_builder_column_inner]

[fusion_builder_column_inner type="1_2" last="yes" spacing="yes" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" border_size="0px" border_color="" border_style="" padding="" class="" id=""]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vel nulla sapien. Class aptent tacitiaptent taciti sociosqu ad lit himenaeos. Suspendisse massa urna, luctus ut vestibulum necs et, vulputate quis urna. Donec at commodo erat. Sed egestas consequat augue eu iaculis. [fusion_popover title="This Is A Popover" title_bg_color="" content="At vero eos et accusamus et iusto odio dignissimos ducimus qui blatis praesentium voluptatum deleni." content_bg_color="" bordercolor="" textcolor="" trigger="hover" placement="top" class="" id=""]Donec elementum pellentesque.[/fusion_popover] Sed gravida, nisl ac lobortis pulvinar, augue est vulputate felis, vel pulvinar ex eros sed est. In hac habitasse platea dicssa. Duis sodales eleifend sem, nonsi semper dui consectetur on roin leoi.

<em>Tempus eget urna id, maximus commodo odio. Lorem ipsum dolor sit amet, consectetur elits sadips. Praesent alis lacus. Nunc at vulputate justo.</em>

[/fusion_text][fusion_separator style_type="none" top_margin="10" bottom_margin="10" sep_color="" icon="" width="" class="" id=""/]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Learn More[/fusion_button]

[fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" type="flat" shape="round" target="_blank" title="" gradient_colors="transparent|" gradient_hover_colors="#6797be|" accent_color="#6797be" accent_hover_color="#ffffff" bevel_color="" border_width="1px" shadow="no" icon="" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="left" class="" id=""]Get A Quote[/fusion_button]

[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_tab][/fusion_tabs][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" overflow="visible" margin_top="15px" margin_bottom="15px"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_separator style_type="none" /][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_image="https://placehold.it/1700x876" background_parallax="left" enable_mobile="no" parallax_speed="0.6" background_repeat="no-repeat" background_position="center center" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="120px" padding_bottom="120px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_2" layout="1_2" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="rgba(255,255,255,.3)" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="30px" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">The Right Tools For The Right Solution. Every Time.</span></h1>
[/fusion_text][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="large" stretch="default" type="flat" shape="round" target="_blank" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255,255,255,.1)" button_gradient_bottom_color_hover="rgba(255,255,255,.1)" accent_color="rgba(255,255,255,.8)" accent_hover_color="#ffffff" border_width="1px" icon_position="left" icon_divider="no" animation_type="0" animation_direction="down" animation_speed="0.1" alignment="center"]PURCHASE AVADA[/fusion_button][fusion_separator style_type="none" top_margin="5" bottom_margin="20" width="200px" /][/fusion_builder_column][fusion_builder_column type="1_2" layout="1_2" spacing="yes" center_content="no" hover_type="none" link="" min_height="" hide_on_mobile="no" class="" id="" background_color="" background_image="" background_position="left top" undefined="" background_repeat="no-repeat" border_size="0" border_color="" border_style="solid" border_position="all" padding="30px" margin_top="" margin_bottom="" animation_type="" animation_direction="left" animation_speed="0.1" animation_offset="" last="no" element_content=""][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="right center" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="0px" padding_bottom="0px" padding_left="0px" padding_right="0px" hundred_percent="yes" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_3" layout="1_3" spacing="no" center_content="no" hover_type="none" link="" min_height="" hide_on_mobile="no" class="" id="" background_color="#6797be" background_image="" background_position="left top" undefined="" background_repeat="no-repeat" border_size="0" border_color="" border_style="solid" border_position="all" padding="10% 13% 8%" margin_top="" margin_bottom="0" animation_type="" animation_direction="down" animation_speed="0.1" animation_offset="" last="no"][fusion_text]
<h3 style="text-align: center;"><span style="color: #ffffff;">The Right Tools. The Right Solution.</span></h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#ffffff" width="200px" /][fusion_text]
<p style="text-align: center;"><span style="color: #ffffff;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores per conubia nostras.</span></p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" spacing="no" center_content="no" hover_type="none" link="" min_height="" hide_on_mobile="no" class="" id="" background_color="#ceaa69" background_image="" background_position="left top" undefined="" background_repeat="no-repeat" border_size="0" border_color="" border_style="solid" border_position="all" padding="10% 13% 8%" margin_top="" margin_bottom="0" animation_type="" animation_direction="down" animation_speed="0.1" animation_offset="" last="no"][fusion_text]
<h3 style="text-align: center;"><span style="color: #ffffff;">The Right Tools. The Right Solution.</span></h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#ffffff" width="200px" /][fusion_text]
<p style="text-align: center;"><span style="color: #ffffff;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores per conubia nostras.</span></p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_3" layout="1_3" spacing="no" center_content="no" hover_type="none" link="" min_height="" hide_on_mobile="no" class="" id="" background_color="#b6c387" background_image="" background_position="left top" undefined="" background_repeat="no-repeat" border_size="0" border_color="" border_style="solid" border_position="all" padding="10% 13% 8%" margin_top="" margin_bottom="" animation_type="" animation_direction="down" animation_speed="0.1" animation_offset="" last="no"][fusion_text]
<h3 style="text-align: center;"><span style="color: #ffffff;">The Right Tools. The Right Solution.</span></h3>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="20" sep_color="#ffffff" width="200px" /][fusion_text]
<p style="text-align: center;"><span style="color: #ffffff;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores per conubia nostras.</span></p>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_parallax="none" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="40px" padding_bottom="55px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;">Avenues To Help Your Business Excel</h1>
[/fusion_text][fusion_separator style_type="single solid" top_margin="5" bottom_margin="65" sep_color="#e0e0e0" width="200px" alignment="center" /][/fusion_builder_column][fusion_builder_column type="1_4" layout="1_4" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="15" bottom_margin="15" width="200px" alignment="center" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_4" layout="1_4" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="15" bottom_margin="15" width="200px" alignment="center" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_4" layout="1_4" last="no" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="15" bottom_margin="15" width="200px" alignment="center" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores.</p>
[/fusion_text][/fusion_builder_column][fusion_builder_column type="1_4" layout="1_4" last="yes" spacing="yes" center_content="no" hide_on_mobile="no" background_color="" background_image="" background_repeat="no-repeat" background_position="left top" hover_type="none" link="" border_position="all" border_size="0px" border_color="" border_style="solid" padding="" margin_top="" margin_bottom="" animation_type="" animation_direction="" animation_speed="0.1" animation_offset="" class="" id="" min_height=""][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/562x348" alt="" />[/fusion_imageframe][fusion_separator style_type="none" top_margin="15" bottom_margin="15" width="200px" alignment="center" /][fusion_text]
<p style="text-align: center;">Lorem ipsum dolor sit amet consetur adipiscing elit. Morbi vel nulla sapien. Class aptent taciti sociosqu ad litora torquent sadips ipsums dolores.</p>
[/fusion_text][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container background_image="https://placehold.it/1600x1002" background_parallax="up" enable_mobile="no" parallax_speed="0.3" background_repeat="no-repeat" background_position="left top" video_aspect_ratio="16:9" video_mute="yes" video_loop="yes" fade="no" border_size="0px" border_style="solid" padding_top="100px" padding_bottom="100px" hundred_percent="no" equal_height_columns="no" hide_on_mobile="no"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_imageframe lightbox="center" style_type="none" hover_type="none" bordersize="0px" borderradius="0" align="center" linktarget="_self" animation_type="fade" animation_direction="up" animation_speed="1" hide_on_mobile="no"] <img src="https://placehold.it/155x120" alt="" />[/fusion_imageframe][/fusion_builder_column][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_text]
<h1 style="text-align: center;"><span style="color: #ffffff;">We\'re Here To Help Your Business Blast Off!</span></h1>
<p style="font-size: 18px; margin-top: -20px; text-align: center;"><span style="color: #ffffff;">Through Creative Ideas, Innovation &amp; Sheer Determination</span></p>
[/fusion_text][fusion_separator style_type="none" top_margin="9" bottom_margin="9" /][fusion_button link="http://themeforest.net/item/avada-responsive-multipurpose-theme/2833226?ref=ThemeFusion" color="custom" size="xlarge" stretch="default" type="flat" shape="round" target="_blank" button_gradient_top_color="rgba(255,255,255,0)" button_gradient_bottom_color="rgba(255,255,255,0)" button_gradient_top_color_hover="rgba(255, 255, 255, 0.09)" button_gradient_bottom_color_hover="rgba(255, 255, 255, 0.09)" accent_color="rgba(255,255,255,.6)" accent_hover_color="rgba(255,255,255,1)" border_width="1px" icon_position="left" icon_divider="no" modal="contact" animation_type="0" animation_direction="left" animation_speed="1" alignment="center"]Let\'s Get Started![/fusion_button][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container][fusion_builder_container hundred_percent="yes" overflow="visible"][fusion_builder_row][fusion_builder_column type="1_1" layout="1_1" background_position="left top" background_color="" border_size="" border_color="" border_style="solid" spacing="yes" background_image="" background_repeat="no-repeat" padding="" margin_top="0px" margin_bottom="0px" class="" id="" animation_type="" animation_speed="0.3" animation_direction="left" hide_on_mobile="no" center_content="no" min_height="none" last="no" hover_type="none" link="" border_position="all"][fusion_modal name="contact" title="We\'d Love To Hear From You!" size="large" background="#ffffff" show_footer="yes"][fusion_builder_row_inner][fusion_builder_column_inner type="2_5" last="no" class="" id=""]
[fusion_separator style_type="none" top_margin="10" bottom_margin="0" sep_color="" icon="" width="" class="" id=""/]

[fusion_imageframe lightbox="no" style_type="none" bordercolor="" bordersize="0px" borderradius="0" stylecolor="" align="none" link="" linktarget="_self" animation_type="0" animation_direction="down" animation_speed="0.1" class="" id=""]<img src="https://placehold.it/250x93" alt="" />[/fusion_imageframe]

[fusion_separator style_type="none" top_margin="5" bottom_margin="5" sep_color="" icon="" width="" class="" id=""/][fusion_text]

Fill out the form and our team will be in touch with you promptly. Thank you for your interest!

<strong>12345 North West Street
New York City, NY 555555
555.555.5555</strong>

info@yourdomain.com
www.yourdomain.com[/fusion_text]
[/fusion_builder_column_inner]

[fusion_builder_column_inner type="3_5" last="yes" class="" id=""]
[fusion_text][contact-form-7 id="11449" title="Contact form 1"][/fusion_text]
[/fusion_builder_column_inner][/fusion_builder_row_inner][/fusion_modal][/fusion_builder_column][/fusion_builder_row][/fusion_builder_container]',
      'meta' => 
      array (
        'pyre_demo_slider' => 'agency-services',
        'pyre_portfolio_width_100' => 'no',
        'pyre_portfolio_content_length' => 'default',
        'pyre_portfolio_excerpt' => '',
        'pyre_portfolio_filters' => 'yes',
        'pyre_portfolio_text_layout' => 'default',
        'pyre_portfolio_featured_image_size' => 'default',
        'pyre_portfolio_column_spacing' => '',
        'pyre_slider_type' => 'flex',
        'pyre_slider' => '0',
        'pyre_wooslider' => 'agency-services',
        'pyre_revslider' => '0',
        'pyre_elasticslider' => '0',
        'pyre_slider_position' => 'default',
        'pyre_avada_rev_styles' => 'default',
        'pyre_fallback' => '',
        'pyre_main_top_padding' => '',
        'pyre_main_bottom_padding' => '0px',
        'pyre_hundredp_padding' => '',
        'pyre_show_first_featured_image' => 'no',
        'pyre_display_header' => 'yes',
        'pyre_header_100_width' => 'default',
        'pyre_header_bg_color' => '',
        'pyre_header_bg_opacity' => '',
        'pyre_header_bg' => '',
        'pyre_header_bg_full' => 'no',
        'pyre_header_bg_repeat' => 'repeat',
        'pyre_displayed_menu' => 'default',
        'pyre_display_footer' => 'default',
        'pyre_display_copyright' => 'default',
        'pyre_footer_100_width' => 'default',
        'pyre_sidebar_position' => 'default',
        'pyre_sidebar_bg_color' => '',
        'pyre_page_bg_layout' => 'default',
        'pyre_page_bg_color' => '',
        'pyre_page_bg' => '',
        'pyre_page_bg_full' => 'no',
        'pyre_page_bg_repeat' => 'repeat',
        'pyre_wide_page_bg_color' => '',
        'pyre_wide_page_bg' => '',
        'pyre_wide_page_bg_full' => 'no',
        'pyre_wide_page_bg_repeat' => 'repeat',
        'pyre_page_title' => 'no',
        'pyre_page_title_breadcrumbs_search_bar' => 'default',
        'pyre_page_title_text' => 'yes',
        'pyre_page_title_text_alignment' => 'default',
        'pyre_page_title_custom_text' => '',
        'pyre_page_title_text_size' => '',
        'pyre_page_title_custom_subheader' => '',
        'pyre_page_title_custom_subheader_text_size' => '',
        'pyre_page_title_font_color' => '',
        'pyre_page_title_100_width' => 'default',
        'pyre_page_title_height' => '',
        'pyre_page_title_mobile_height' => '',
        'pyre_page_title_bar_bg_color' => '',
        'pyre_page_title_bar_borders_color' => '',
        'pyre_page_title_bar_bg' => '',
        'pyre_page_title_bar_bg_retina' => '',
        'pyre_page_title_bar_bg_full' => 'default',
        'pyre_page_title_bg_parallax' => 'default',
      ),
    ),
  ),
);

			return $demos;
		}
		add_filter( 'fusion_builder_get_demo_pages', 'fusion_builder_add_agency_demo' );